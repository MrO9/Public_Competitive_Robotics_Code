#ifndef __TASKS_TELEOP_H__
#define __TASKS_TELEOP_H__

#ifdef __cplusplus
extern "C"
{
#endif

void opcontrol(void);
void opcontrol_initialize(void);

#ifdef __cplusplus
}
#endif

#endif